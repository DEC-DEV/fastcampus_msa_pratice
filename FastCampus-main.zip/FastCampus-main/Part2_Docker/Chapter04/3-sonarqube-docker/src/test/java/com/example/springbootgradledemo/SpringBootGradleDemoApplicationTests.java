package com.example.springbootgradledemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootGradleDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
