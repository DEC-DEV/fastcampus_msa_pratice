# Gradle 관련 질의응답 모음집입니다.

Gradle 실습시 질의주신 내용에 대한 응답 모음집입니다. 에러에 대한 해결 방법도 같이 명시하였습니다.

> Gradle 활용 질의응답 모음은 각 항목별로 계속 업데이트 할 예정입니다.
>
> (링크를 클릭하시면 해당 카테고리의 질의응답을 확인하실 수 있으십니다.)
## * [Gradle_JAVA_Change](detail/Gradle_JAVA_Change.md)
## * [Gradle_Upgrade](detail/Gradle_Upgrade.md)