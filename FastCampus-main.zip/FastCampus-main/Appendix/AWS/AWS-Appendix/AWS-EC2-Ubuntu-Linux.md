# Ubuntu Linux 정보 확인 방법입니다.

Ubuntu Linux 정보 확인 방법입니다. 

## 1. Ubuntu 리눅스 서버 정보 확인 방법
(1) Ubuntu OS 버전 확인
* 명령어
```
$ cat /etc/lsb-release
```

(2) OS 커널 버전 및 아키텍처 확인
* 명령어
```
$ uname -a
```

* 명령어 수행 예시
![linux_ver_arch](https://devopsrunbook-fastcampus.s3.ap-northeast-2.amazonaws.com/FastCampus/Part2_Docker/QnA/linux_ver_arch.png)
