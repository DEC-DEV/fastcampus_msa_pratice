# AWS 부록(Appendix) 모음
> AWS 부록(Appendix) 모음은 각 항목별로 계속 업데이트 할 예정입니다.
>
> (링크를 클릭하시면 해당 카테고리의 부록을 확인하실 수 있으십니다.)
## * [AWS Configure 설정 방법](AWS-Appendix/AWS-Configure.md)
## * [AWS EC2에서 JAVA JDK 설치 방법](AWS-Appendix/AWS-EC2-JAVA-JDK.md)
## * [AWS EC2 - Ubuntu Linux 정보 확인 방법](AWS-Appendix/AWS-EC2-Ubuntu-Linux.md)
## * [AWS ECR 구성 및 관리](AWS-Appendix/AWS-ECR.md)
## * [AWS 리소스를 Terraform으로 프로비저닝하는 방법](AWS-Appendix/AWS-Provisioning-Terraform.md)